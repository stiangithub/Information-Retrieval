#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 22 15:20:21 2018

@author: stian
"""

f = open("results/stem_query_likelihood/query_likelihood_query3.txt",'r')
score = []
for i in f.readlines():
    score.append(float(i.split()[4]))
average_score = sum(score)/len(score)
f.close()